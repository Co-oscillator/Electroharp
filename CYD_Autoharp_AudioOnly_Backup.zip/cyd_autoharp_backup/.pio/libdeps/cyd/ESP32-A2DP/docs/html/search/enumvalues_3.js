var searchData=
[
  ['right_375',['Right',['../group__a2dp.html#ggadd07e8b0b75b5153b83a4580f2d5c6c0ad48f7af8c070184f3774c8e85854eb66',1,'SoundData.h']]]
];
